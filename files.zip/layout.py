# ─────────────────────────────────────────────
#  layout.py
#  Builds the Dash HTML layout.
#  No callbacks here — just structure + style.
# ─────────────────────────────────────────────

from dash import dcc, html
from config import TASK_NAME, MODEL_NAME, COLORS

# ── Reusable card wrapper ──────────────────────────────────────────────────────

def _card(children, extra_style: dict = None):
    style = {
        "background": COLORS["surface"],
        "border": f"1px solid {COLORS['border']}",
        "borderRadius": "8px",
        "padding": "6px",
        "boxShadow": "0 4px 24px rgba(0,0,0,0.4)",
    }
    if extra_style:
        style.update(extra_style)
    return html.Div(children, style=style)


def _graph_card(graph_id: str):
    return _card(
        dcc.Graph(
            id=graph_id,
            config={"displayModeBar": False},
            style={"height": "280px"},
        )
    )


# ── Status badge ───────────────────────────────────────────────────────────────

def _status_dot():
    return html.Div(
        style={
            "display": "flex", "alignItems": "center", "gap": "8px",
            "fontFamily": "'JetBrains Mono', monospace",
            "fontSize": "11px", "color": "#64748b",
        },
        children=[
            html.Div(
                id="status-dot",
                style={
                    "width": "8px", "height": "8px",
                    "borderRadius": "50%",
                    "background": "#22c55e",
                    "boxShadow": "0 0 6px #22c55e",
                    "animation": "pulse 2s infinite",
                },
            ),
            html.Span(id="status-text", children="LIVE"),
        ],
    )


# ── Sample images panel ────────────────────────────────────────────────────────

def _sample_card(idx: int):
    return html.Div(
        id=f"sample-{idx}",
        style={
            "display": "flex", "flexDirection": "column", "alignItems": "center",
            "background": "#0d1520",
            "border": f"1px solid {COLORS['border']}",
            "borderRadius": "8px",
            "padding": "8px",
            "gap": "6px",
            "minWidth": "0",
        },
        children=[
            html.Img(
                id=f"sample-img-{idx}",
                style={
                    "width": "100%", "aspectRatio": "1/1",
                    "objectFit": "cover", "borderRadius": "4px",
                    "display": "none",
                },
            ),
            html.Div(
                id=f"sample-label-{idx}",
                style={
                    "fontFamily": "'JetBrains Mono', monospace",
                    "fontSize": "10px", "color": "#64748b",
                    "textAlign": "center", "lineHeight": "1.4",
                },
            ),
        ],
    )


def build_layout():
    return html.Div(
        style={
            "minHeight": "100vh",
            "background": COLORS["bg"],
            "fontFamily": "'JetBrains Mono', monospace",
            "padding": "24px 28px",
            "boxSizing": "border-box",
        },
        children=[
            # ── Global CSS ──────────────────────────────────────────────────────
            html.Style("""
                @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600;700&display=swap');
                * { box-sizing: border-box; }
                ::-webkit-scrollbar { width: 6px; background: #0a0e1a; }
                ::-webkit-scrollbar-thumb { background: #1f2937; border-radius: 3px; }
                @keyframes pulse {
                    0%,100% { box-shadow: 0 0 6px #22c55e; }
                    50%      { box-shadow: 0 0 14px #22c55e; }
                }
                @keyframes fadeIn { from { opacity:0; transform:translateY(6px); } to { opacity:1; transform:none; } }
                .metric-card { animation: fadeIn 0.4s ease both; }
            """),

            # ── Header ──────────────────────────────────────────────────────────
            html.Div(
                style={
                    "display": "flex", "justifyContent": "space-between",
                    "alignItems": "flex-end", "marginBottom": "28px",
                    "borderBottom": f"1px solid {COLORS['border']}",
                    "paddingBottom": "16px",
                },
                children=[
                    html.Div([
                        html.Div(
                            "TRAINING MONITOR",
                            style={
                                "fontSize": "10px", "letterSpacing": "4px",
                                "color": COLORS["train"], "marginBottom": "4px",
                                "fontWeight": "600",
                            },
                        ),
                        html.H1(
                            TASK_NAME,
                            style={
                                "margin": "0", "fontSize": "22px",
                                "fontWeight": "700", "color": "#e2e8f0",
                                "letterSpacing": "-0.5px",
                            },
                        ),
                        html.Div(
                            MODEL_NAME,
                            style={"fontSize": "11px", "color": "#475569", "marginTop": "2px"},
                        ),
                    ]),
                    html.Div(
                        style={"display": "flex", "flexDirection": "column", "alignItems": "flex-end", "gap": "6px"},
                        children=[
                            _status_dot(),
                            html.Div(id="epoch-counter", style={"fontSize": "11px", "color": "#475569"}),
                        ],
                    ),
                ],
            ),

            # ── Summary strip ────────────────────────────────────────────────────
            html.Div(
                id="summary-strip",
                style={
                    "display": "grid",
                    "gridTemplateColumns": "repeat(4, 1fr)",
                    "gap": "12px",
                    "marginBottom": "24px",
                },
                children=[
                    _summary_metric("latest-train-loss",  "TRAIN LOSS",  COLORS["train"]),
                    _summary_metric("latest-test-loss",   "TEST LOSS",   COLORS["test"]),
                    _summary_metric("latest-train-acc",   "TRAIN ACC",   COLORS["train"]),
                    _summary_metric("latest-test-acc",    "TEST ACC",    COLORS["test"]),
                ],
            ),

            # ── 6 Graphs (2-column grid) ─────────────────────────────────────────
            html.Div(
                style={
                    "display": "grid",
                    "gridTemplateColumns": "1fr 1fr",
                    "gap": "16px",
                    "marginBottom": "24px",
                },
                children=[
                    _graph_card("graph-step-train-loss"),
                    _graph_card("graph-test-loss"),
                    _graph_card("graph-train-acc"),
                    _graph_card("graph-test-acc"),
                    _graph_card("graph-combined-loss"),
                    _graph_card("graph-combined-acc"),
                ],
            ),

            # ── Sample predictions panel ─────────────────────────────────────────
            _card([
                html.Div(
                    style={
                        "display": "flex", "justifyContent": "space-between",
                        "alignItems": "center", "marginBottom": "12px",
                        "padding": "4px 6px",
                    },
                    children=[
                        html.Div(
                            "SAMPLE PREDICTIONS",
                            style={
                                "fontSize": "10px", "letterSpacing": "3px",
                                "color": "#475569", "fontWeight": "600",
                            },
                        ),
                        html.Div(id="samples-epoch-tag", style={"fontSize": "10px", "color": "#334155"}),
                    ],
                ),
                html.Div(
                    id="samples-grid",
                    style={
                        "display": "grid",
                        "gridTemplateColumns": "repeat(10, 1fr)",
                        "gap": "10px",
                    },
                    children=[_sample_card(i) for i in range(10)],
                ),
            ]),

            # ── Interval for live updates ────────────────────────────────────────
            dcc.Interval(id="interval", interval=1500, n_intervals=0),
        ],
    )


def _summary_metric(metric_id: str, label: str, color: str):
    return _card(
        html.Div(
            className="metric-card",
            style={"padding": "8px 10px"},
            children=[
                html.Div(label, style={"fontSize": "9px", "letterSpacing": "2px", "color": "#475569", "marginBottom": "6px"}),
                html.Div(
                    id=metric_id,
                    children="—",
                    style={"fontSize": "22px", "fontWeight": "700", "color": color, "letterSpacing": "-1px"},
                ),
            ],
        )
    )
