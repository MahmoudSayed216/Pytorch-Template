# ─────────────────────────────────────────────
#  ingest_server.py
#  Lightweight Flask server that receives metrics POSTed from Kaggle.
#  Runs in a background thread inside the Dash process.
# ─────────────────────────────────────────────

from flask import Flask, request, jsonify
from pyngrok import ngrok
import threading
import data_store
from config import FLASK_PORT

ingest_app = Flask(__name__)

# ── Routes ─────────────────────────────────────────────────────────────────────

@ingest_app.route("/log/step", methods=["POST"])
def log_step():
    """
    Called after every mini-batch.
    Expected JSON: {"loss": <float>}
    """
    data = request.get_json(force=True)
    loss = float(data["loss"])
    data_store.append_step_loss(loss)
    return jsonify({"status": "ok"}), 200


@ingest_app.route("/log/epoch", methods=["POST"])
def log_epoch():
    """
    Called at the end of every epoch.
    Expected JSON:
    {
        "epoch":          <int>,
        "avg_train_loss": <float>,
        "test_loss":      <float>,
        "train_acc":      <float>,
        "test_acc":       <float>
    }
    """
    data = request.get_json(force=True)
    data_store.append_epoch_metrics(
        epoch=int(data["epoch"]),
        avg_train_loss=float(data["avg_train_loss"]),
        test_loss=float(data["test_loss"]),
        train_acc=float(data["train_acc"]),
        test_acc=float(data["test_acc"]),
    )
    return jsonify({"status": "ok"}), 200


@ingest_app.route("/log/samples", methods=["POST"])
def log_samples():
    """
    Called when the training script wants to push sample predictions.
    Expected JSON:
    {
        "samples": [
            {
                "image_b64":  "<base64-encoded PNG/JPEG>",
                "true_label": "Dog",
                "pred_label": "Dog",
                "confidence": 0.97
            },
            ...
        ]
    }
    """
    data = request.get_json(force=True)
    data_store.set_samples(data.get("samples", []))
    return jsonify({"status": "ok"}), 200


@ingest_app.route("/reset", methods=["POST"])
def reset():
    """Clear all stored data (start of a new run)."""
    data_store.clear()
    return jsonify({"status": "cleared"}), 200


@ingest_app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "alive"}), 200


# ── Runner ─────────────────────────────────────────────────────────────────────

def start_ingest_server(use_ngrok: bool = True, ngrok_token: str = "") -> str:
    """
    Start the ingest Flask server in a daemon thread.
    Returns the public URL (ngrok) or local URL.
    """
    public_url = f"http://localhost:{FLASK_PORT}"

    if use_ngrok and ngrok_token:
        ngrok.set_auth_token(ngrok_token)
        tunnel = ngrok.connect(FLASK_PORT)
        public_url = tunnel.public_url
        print(f"[Ingest] ngrok public URL: {public_url}")
    else:
        print(f"[Ingest] Running locally on port {FLASK_PORT}")

    thread = threading.Thread(
        target=lambda: ingest_app.run(port=FLASK_PORT, use_reloader=False),
        daemon=True,
    )
    thread.start()
    return public_url
