# ML Training Dashboard

Real-time training monitor built with **Dash + Plotly** (local) and a lightweight **Flask ingest server** that receives metrics POST'd from your Kaggle notebook over ngrok.

## File Structure

```
ml_dashboard/
├── app.py                  ← Entry point – run this on your local machine
├── config.py               ← All tuneable settings (task name, colors, class names…)
├── layout.py               ← Dash HTML/CSS layout
├── callbacks.py            ← Dash live-update callbacks
├── graphs.py               ← Plotly figure factories (one per graph)
├── data_store.py           ← Thread-safe in-memory data store
├── ingest_server.py        ← Flask server that receives data from Kaggle
├── dashboard_reporter.py   ← Copy to Kaggle; call from your training loop
├── train_with_dashboard.py ← Reference training loop with reporter calls added
└── requirements.txt
```

## Quick Start

### 1. Install dependencies (local machine)
```bash
pip install dash plotly flask pyngrok requests
```

### 2. Start the dashboard
```bash
cd ml_dashboard
python app.py
```

The terminal prints something like:
```
============================================================
  Ingest server URL:  https://xxxx.ngrok-free.app
  Use this as SERVER_URL in your Kaggle notebook
============================================================
```

Open `http://localhost:8050` in your browser.

### 3. Set up Kaggle
- Upload `dashboard_reporter.py` to your Kaggle notebook.
- Set `SERVER_URL` in `train_with_dashboard.py` to the ngrok URL from step 2.
- Add the three reporter calls shown in `train_with_dashboard.py`.

## Dashboard Panels

| Graph | X-axis | Update frequency |
|---|---|---|
| Train Loss (per step) | Mini-batch step | Every mini-batch |
| Test Loss | Epoch | Every epoch |
| Train Accuracy | Epoch | Every epoch |
| Test Accuracy | Epoch | Every epoch |
| Avg Train Loss vs Test Loss | Epoch | Every epoch |
| Train Acc vs Test Acc | Epoch | Every epoch |
| Sample Predictions (10 images) | — | Every epoch |

## Adapting to a New Task

1. Edit **`config.py`**: update `TASK_NAME`, `MODEL_NAME`, `CLASS_NAMES`.
2. If your task is multi-class (softmax), update the `_send_samples` helper in `train_with_dashboard.py` to extract `pred_label` and `confidence` from your output.
3. If you need more/fewer sample images, change `NUM_SAMPLES` in `config.py`.
