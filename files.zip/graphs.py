# ─────────────────────────────────────────────
#  graphs.py
#  Plotly figure factories for each graph panel.
#  All figures share a consistent dark theme.
# ─────────────────────────────────────────────

import plotly.graph_objects as go
import plotly.express as px
from config import COLORS, METRIC_LABELS

# ── Shared theme helper ────────────────────────────────────────────────────────

def _base_layout(title: str, xaxis_title: str, yaxis_title: str) -> dict:
    return dict(
        title=dict(text=title, font=dict(family="'JetBrains Mono', monospace", size=13, color="#94a3b8"), x=0.03),
        plot_bgcolor=COLORS["surface"],
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="'JetBrains Mono', monospace", color="#64748b", size=10),
        xaxis=dict(
            title=xaxis_title,
            gridcolor="#1e2a3a",
            zerolinecolor="#1e2a3a",
            tickfont=dict(color="#475569"),
            titlefont=dict(color="#64748b"),
        ),
        yaxis=dict(
            title=yaxis_title,
            gridcolor="#1e2a3a",
            zerolinecolor="#1e2a3a",
            tickfont=dict(color="#475569"),
            titlefont=dict(color="#64748b"),
        ),
        margin=dict(l=50, r=20, t=45, b=40),
        legend=dict(
            bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94a3b8", size=10),
            x=0.98, xanchor="right", y=0.98,
        ),
        hovermode="x unified",
        hoverlabel=dict(bgcolor="#1e293b", font_color="#e2e8f0", font_family="'JetBrains Mono', monospace"),
    )


def _line(x, y, color: str, name: str, dash: str = "solid") -> go.Scatter:
    return go.Scatter(
        x=x, y=y,
        mode="lines+markers",
        name=name,
        line=dict(color=color, width=2, dash=dash),
        marker=dict(size=4, color=color, symbol="circle"),
        hovertemplate=f"<b>{name}</b>: %{{y:.6f}}<extra></extra>",
    )


def _empty_figure(title: str, xaxis_title: str, yaxis_title: str) -> go.Figure:
    fig = go.Figure()
    fig.update_layout(**_base_layout(title, xaxis_title, yaxis_title))
    return fig


# ── Individual graph factories ─────────────────────────────────────────────────

def make_step_train_loss_fig(step_train_loss: list) -> go.Figure:
    fig = go.Figure()
    if step_train_loss:
        steps = list(range(1, len(step_train_loss) + 1))
        fig.add_trace(_line(steps, step_train_loss, COLORS["train"], METRIC_LABELS["train_loss"]))
    fig.update_layout(**_base_layout(
        title="Train Loss  ·  per step",
        xaxis_title="Step",
        yaxis_title="Loss",
    ))
    return fig


def make_test_loss_fig(epochs: list, test_loss: list) -> go.Figure:
    fig = go.Figure()
    if epochs:
        fig.add_trace(_line(epochs, test_loss, COLORS["test"], METRIC_LABELS["test_loss"]))
    fig.update_layout(**_base_layout(
        title="Test Loss  ·  per epoch",
        xaxis_title="Epoch",
        yaxis_title="Loss",
    ))
    return fig


def make_train_acc_fig(epochs: list, train_acc: list) -> go.Figure:
    fig = go.Figure()
    if epochs:
        fig.add_trace(_line(epochs, train_acc, COLORS["train"], METRIC_LABELS["train_acc"]))
    fig.update_layout(**_base_layout(
        title="Train Accuracy  ·  per epoch",
        xaxis_title="Epoch",
        yaxis_title="Accuracy",
    ))
    fig.update_yaxes(range=[0, 1])
    return fig


def make_test_acc_fig(epochs: list, test_acc: list) -> go.Figure:
    fig = go.Figure()
    if epochs:
        fig.add_trace(_line(epochs, test_acc, COLORS["test"], METRIC_LABELS["test_acc"]))
    fig.update_layout(**_base_layout(
        title="Test Accuracy  ·  per epoch",
        xaxis_title="Epoch",
        yaxis_title="Accuracy",
    ))
    fig.update_yaxes(range=[0, 1])
    return fig


def make_combined_loss_fig(epochs: list, avg_train_loss: list, test_loss: list) -> go.Figure:
    fig = go.Figure()
    if epochs:
        fig.add_trace(_line(epochs, avg_train_loss, COLORS["train"],  METRIC_LABELS["avg_train_loss"]))
        fig.add_trace(_line(epochs, test_loss,       COLORS["test"],   METRIC_LABELS["test_loss"], dash="dot"))
    fig.update_layout(**_base_layout(
        title="Avg Train Loss  vs  Test Loss  ·  per epoch",
        xaxis_title="Epoch",
        yaxis_title="Loss",
    ))
    return fig


def make_combined_acc_fig(epochs: list, train_acc: list, test_acc: list) -> go.Figure:
    fig = go.Figure()
    if epochs:
        fig.add_trace(_line(epochs, train_acc, COLORS["train"], METRIC_LABELS["train_acc"]))
        fig.add_trace(_line(epochs, test_acc,  COLORS["test"],  METRIC_LABELS["test_acc"], dash="dot"))
    fig.update_layout(**_base_layout(
        title="Train Acc  vs  Test Acc  ·  per epoch",
        xaxis_title="Epoch",
        yaxis_title="Accuracy",
    ))
    fig.update_yaxes(range=[0, 1])
    return fig
