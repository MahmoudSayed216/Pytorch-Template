# ─────────────────────────────────────────────
#  callbacks.py
#  All Dash callbacks – wired to the Interval component.
# ─────────────────────────────────────────────

from dash import Input, Output, callback, no_update
import data_store
import graphs


def register_callbacks(app):

    @app.callback(
        # 6 graphs
        Output("graph-step-train-loss", "figure"),
        Output("graph-test-loss",        "figure"),
        Output("graph-train-acc",         "figure"),
        Output("graph-test-acc",          "figure"),
        Output("graph-combined-loss",     "figure"),
        Output("graph-combined-acc",      "figure"),
        # summary strip
        Output("latest-train-loss",  "children"),
        Output("latest-test-loss",   "children"),
        Output("latest-train-acc",   "children"),
        Output("latest-test-acc",    "children"),
        # header
        Output("epoch-counter",      "children"),
        Input("interval",            "n_intervals"),
    )
    def update_graphs(_n):
        snap = data_store.get_snapshot()

        step_loss   = snap["step_train_loss"]
        epochs      = snap["epochs"]
        avg_tr_loss = snap["avg_train_loss"]
        te_loss     = snap["test_loss"]
        tr_acc      = snap["train_acc"]
        te_acc      = snap["test_acc"]

        # ── Figures ────────────────────────────────────────────────────────
        fig_step  = graphs.make_step_train_loss_fig(step_loss)
        fig_tl    = graphs.make_test_loss_fig(epochs, te_loss)
        fig_tra   = graphs.make_train_acc_fig(epochs, tr_acc)
        fig_tea   = graphs.make_test_acc_fig(epochs, te_acc)
        fig_closs = graphs.make_combined_loss_fig(epochs, avg_tr_loss, te_loss)
        fig_cacc  = graphs.make_combined_acc_fig(epochs, tr_acc, te_acc)

        # ── Summary numbers ────────────────────────────────────────────────
        fmt_loss = lambda v: f"{v:.5f}" if v else "—"
        fmt_acc  = lambda v: f"{v*100:.2f}%" if v else "—"

        latest_trl  = fmt_loss(step_loss[-1]  if step_loss  else None)
        latest_tel  = fmt_loss(te_loss[-1]    if te_loss    else None)
        latest_tra  = fmt_acc(tr_acc[-1]      if tr_acc     else None)
        latest_tea  = fmt_acc(te_acc[-1]      if te_acc     else None)

        epoch_txt = f"Epoch {epochs[-1]}" if epochs else "Waiting…"

        return (
            fig_step, fig_tl, fig_tra, fig_tea, fig_closs, fig_cacc,
            latest_trl, latest_tel, latest_tra, latest_tea,
            epoch_txt,
        )

    # ── Sample image callbacks ─────────────────────────────────────────────────

    # Build one combined callback for all 10 sample slots
    img_outputs  = [Output(f"sample-img-{i}",   "src")           for i in range(10)]
    img_styles   = [Output(f"sample-img-{i}",   "style")         for i in range(10)]
    label_outs   = [Output(f"sample-label-{i}", "children")      for i in range(10)]

    @app.callback(
        *img_outputs,
        *img_styles,
        *label_outs,
        Output("samples-epoch-tag", "children"),
        Input("interval", "n_intervals"),
    )
    def update_samples(_n):
        snap    = data_store.get_snapshot()
        samples = snap["samples"][:10]          # cap at 10
        epochs  = snap["epochs"]

        srcs   = []
        styles = []
        labels = []

        base_img_style = {
            "width": "100%", "aspectRatio": "1/1",
            "objectFit": "cover", "borderRadius": "4px",
        }

        for i in range(10):
            if i < len(samples):
                s = samples[i]
                b64 = s.get("image_b64", "")
                src = f"data:image/jpeg;base64,{b64}" if b64 else ""
                srcs.append(src)

                # border color: green if correct, red if wrong
                correct = s.get("true_label", "?") == s.get("pred_label", "!")
                border_color = "#22c55e" if correct else "#ef4444"
                style = {**base_img_style, "display": "block", "border": f"2px solid {border_color}"}
                styles.append(style)

                conf = s.get("confidence", 0)
                label_txt = (
                    f"True: {s.get('true_label','?')}\n"
                    f"Pred: {s.get('pred_label','?')}\n"
                    f"Conf: {conf*100:.1f}%"
                )
                labels.append(label_txt)
            else:
                srcs.append("")
                styles.append({**base_img_style, "display": "none"})
                labels.append("")

        epoch_tag = f"@ epoch {epochs[-1]}" if epochs else ""
        return (*srcs, *styles, *labels, epoch_tag)
