# ─────────────────────────────────────────────
#  app.py  –  Entry point
#  Run: python app.py
# ─────────────────────────────────────────────

import dash
from layout import build_layout
from callbacks import register_callbacks
from ingest_server import start_ingest_server
from config import SERVER_HOST, SERVER_PORT

# ── Optional: set your ngrok token here or leave blank to run locally ──────────
NGROK_TOKEN = "3AtbqRbtKoMcQHExzTMLaA7dTCr_Sb8BJEALNzYfmQiDnpwJ"   # ← paste token
USE_NGROK   = bool(NGROK_TOKEN)

# ── Start Flask ingest server (background thread) ──────────────────────────────
public_url = start_ingest_server(use_ngrok=USE_NGROK, ngrok_token=NGROK_TOKEN)
print(f"\n{'='*60}")
print(f"  Ingest server URL:  {public_url}")
print(f"  Use this as SERVER_URL in your Kaggle notebook")
print(f"{'='*60}\n")

# ── Build Dash app ─────────────────────────────────────────────────────────────
app = dash.Dash(
    __name__,
    title="Training Monitor",
    update_title=None,
)
app.layout = build_layout()
register_callbacks(app)

# ── Launch dashboard ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    app.run(host=SERVER_HOST, port=SERVER_PORT, debug=False)
